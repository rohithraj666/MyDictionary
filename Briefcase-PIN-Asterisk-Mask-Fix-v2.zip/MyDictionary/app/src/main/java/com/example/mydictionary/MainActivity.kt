package com.example.mydictionary

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import android.net.Uri
import android.view.Menu
import android.view.MenuItem
import android.widget.PopupMenu
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(val id: String, val word: String, val definition: String, val example: String = "")

class MainActivity : AppCompatActivity() {
    private var entries = mutableListOf<Entry>()
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private lateinit var root: LinearLayout
    private var currentPage: String = "home"
    private var editorReturnEntry: Entry? = null
    private var lockPromptShown = false
    private val lockPrefs by lazy { getSharedPreferences("briefcase_lock", MODE_PRIVATE) }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) exportEntries(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importEntries(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }
    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun actionButton(textValue: String, size: Float = 14f) = Button(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(Color.rgb(38, 38, 38))
        minHeight = dp(32)
    }

    private fun inputField(hintText: String, size: Float) = EditText(this).apply {
        hint = hintText
        textSize = size
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(165, 165, 165))
        backgroundTintList = ColorStateList.valueOf(Color.rgb(110, 110, 110))
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Use black system bars and keep content safely between them.
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        load(); home()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (currentPage) {
            "details" -> home()
            "editor" -> {
                val previous = editorReturnEntry
                if (previous != null) {
                    val updated = entries.firstOrNull { it.id == previous.id } ?: previous
                    details(updated)
                } else home()
            }
            else -> super.onBackPressed()
        }
    }

    private fun load() {
        entries.clear()
        val raw = getSharedPreferences("my_dictionary", MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                entries.add(Entry(o.optString("id"), o.optString("word"), o.optString("definition"), o.optString("example")))
            }
        } catch (_: Exception) { }
        entries.sortBy { it.word.lowercase() }
    }

    private fun save() {
        val a = JSONArray()
        entries.forEach { a.put(JSONObject().put("id", it.id).put("word", it.word).put("definition", it.definition).put("example", it.example)) }
        getSharedPreferences("my_dictionary", MODE_PRIVATE).edit().putString("entries", a.toString()).apply()
    }

    private fun home() {
        currentPage = "home"
        editorReturnEntry = null
        root = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("Briefcase", 18f), LinearLayout.LayoutParams(0, dp(30), 1f))
        top.addView(actionButton("+", 18f).apply { minWidth = dp(42); setOnClickListener { editor(null) } })
        top.addView(actionButton("⋮", 18f).apply {
            minWidth = dp(36)
            setOnClickListener { showDataMenu(this) }
        })
        root.addView(top)
        search = EditText(this).apply { hint = "Search words"; textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(165,165,165)); setSingleLine(true); setPadding(dp(5), 0, dp(5), 0); background = null }
        val searchBox = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), 0); setBackgroundColor(Color.rgb(24,24,24)) }
        searchBox.addView(label("⌕", 17f, Color.LTGRAY), LinearLayout.LayoutParams(dp(20), dp(28)))
        searchBox.addView(search, LinearLayout.LayoutParams(0, dp(28), 1f))
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(28)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root); render()
    }


    private fun showDataMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Export words to file")
        popup.menu.add("Import words from file")
        popup.menu.add("App lock settings")
        popup.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Export words to file" -> exportLauncher.launch("my_dictionary_backup.json")
                "Import words from file" -> importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream"))
                "App lock settings" -> showLockMenu(anchor)
            }
            true
        }
        popup.show()
    }

    private fun entriesJson(items: List<Entry>): JSONArray {
        val array = JSONArray()
        items.forEach { e ->
            array.put(JSONObject().put("id", e.id).put("word", e.word).put("definition", e.definition).put("example", e.example))
        }
        return array
    }

    private fun exportEntries(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(entriesJson(entries).toString(2)) }
                ?: throw IllegalStateException("Could not open the selected file")
            Toast.makeText(this, "Exported ${entries.size} words", Toast.LENGTH_LONG).show()
        } catch (ex: Exception) {
            Toast.makeText(this, "Export failed: ${ex.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importEntries(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Could not read the selected file")
            val array = JSONArray(raw)
            val imported = mutableListOf<Entry>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val word = o.optString("word").trim()
                val definition = o.optString("definition").trim()
                if (word.isNotBlank() && definition.isNotBlank()) {
                    imported.add(Entry(o.optString("id").ifBlank { UUID.randomUUID().toString() }, word, definition, o.optString("example")))
                }
            }
            if (imported.isEmpty() && array.length() > 0) throw IllegalArgumentException("No valid word entries found")
            AlertDialog.Builder(this)
                .setTitle("Import words")
                .setMessage("Found ${imported.size} words. Replace your current list, or merge them with existing words? Matching words are identified by word name.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Replace") { _, _ ->
                    entries = imported.distinctBy { it.word.lowercase() }.toMutableList()
                    entries.sortBy { it.word.lowercase() }; save(); home()
                    Toast.makeText(this, "Imported ${entries.size} words", Toast.LENGTH_LONG).show()
                }
                .setPositiveButton("Merge") { _, _ ->
                    val combined = entries.toMutableList()
                    imported.forEach { incoming ->
                        val index = combined.indexOfFirst { it.word.equals(incoming.word, ignoreCase = true) }
                        if (index >= 0) combined[index] = incoming else combined.add(incoming)
                    }
                    entries = combined.distinctBy { it.word.lowercase() }.toMutableList()
                    entries.sortBy { it.word.lowercase() }; save(); home()
                    Toast.makeText(this, "Imported words; total ${entries.size}", Toast.LENGTH_LONG).show()
                }
                .show()
        } catch (ex: Exception) {
            Toast.makeText(this, "Import failed. Choose a valid dictionary JSON file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        entries.filter { it.word.lowercase().contains(q) }.forEach { e ->
            list.addView(TextView(this).apply {
                text = e.word; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), 0, dp(6), 0); minHeight = dp(30); setBackgroundColor(Color.rgb(8,8,8)); setOnClickListener { details(e) }
            }, LinearLayout.LayoutParams(-1, dp(30)).apply { bottomMargin = dp(2) })
        }
    }

    private fun copyRow(title: String, value: String, size: Float = 14f, color: Int = Color.WHITE) : LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(2), dp(5), dp(2), dp(5))
            val text = TextView(this@MainActivity).apply {
                text = if (value.isBlank()) "—" else value
                textSize = size; setTextColor(color); setPadding(0, 0, dp(6), 0)
            }
            addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            addView(actionButton("▢", 18f).apply {
                contentDescription = "Copy $title"
                minWidth = dp(42); setPadding(0, 0, 0, 0)
                setOnClickListener {
                    val clip = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clip.setPrimaryClip(android.content.ClipData.newPlainText(title, value))
                    Toast.makeText(this@MainActivity, "$title copied", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(dp(42), dp(36)))
        }
    }

    private fun details(e: Entry) {
        currentPage = "details"
        editorReturnEntry = null
        val page = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(actionButton("‹").apply { setOnClickListener { home() } })
        top.addView(label("Word", 12f, Color.LTGRAY), LinearLayout.LayoutParams(0, dp(40), 1f))
        top.addView(actionButton("Edit").apply { layoutParams = LinearLayout.LayoutParams(dp(72), dp(36)); setOnClickListener { editor(e) } })
        page.addView(top)
        page.addView(copyRow("Word", e.word, 18f))
        page.addView(copyRow("Definition", e.definition, 14f))
        page.addView(label("Remarks", 12f, Color.LTGRAY).apply { setPadding(dp(2), dp(4), 0, 0) })
        page.addView(copyRow("Remarks", e.example, 13f, Color.LTGRAY))
        val deleteRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END; setPadding(0, dp(2), 0, 0) }
        deleteRow.addView(actionButton("Delete").apply {
            layoutParams = LinearLayout.LayoutParams(dp(88), dp(36))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("Delete ‘${e.word}’?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> entries.removeAll { it.id == e.id }; save(); home() }.show()
            }
        })
        page.addView(deleteRow)
        setContentView(page)
    }

    private fun showLockMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Set / change PIN")
        popup.menu.add("Disable app lock")
        val fingerprintEnabled = lockPrefs.getBoolean("fingerprint", false)
        popup.menu.add(if (fingerprintEnabled) "Fingerprint unlock: ON (tap to turn OFF)" else "Fingerprint unlock: OFF (tap to turn ON)")
        popup.setOnMenuItemClickListener { item ->
            when {
                item.title.toString() == "Set / change PIN" -> setPinDialog()
                item.title.toString() == "Disable app lock" -> {
                    lockPrefs.edit().remove("pin").putBoolean("fingerprint", false).apply()
                    lockPromptShown = false
                    Toast.makeText(this, "App lock disabled", Toast.LENGTH_SHORT).show()
                }
                item.title.toString().startsWith("Fingerprint unlock:") -> {
                    if (fingerprintEnabled) {
                        lockPrefs.edit().putBoolean("fingerprint", false).apply()
                        Toast.makeText(this, "Fingerprint unlock disabled", Toast.LENGTH_SHORT).show()
                    } else {
                        val available = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
                        if (!available) Toast.makeText(this, "Set up fingerprint/biometric unlock in Android settings first", Toast.LENGTH_LONG).show()
                        else {
                            lockPrefs.edit().putBoolean("fingerprint", true).apply()
                            Toast.makeText(this, "Fingerprint unlock enabled", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            true
        }
        popup.show()
    }

    /** Transformation that always displays one literal asterisk per entered PIN digit. */
    private class AsteriskPinTransformation : android.text.method.TransformationMethod {
        override fun getTransformation(source: CharSequence?, view: View?): CharSequence {
            return source?.let { "*".repeat(it.length) } ?: ""
        }

        override fun onFocusChanged(
            view: View?,
            sourceText: CharSequence?,
            focused: Boolean,
            direction: Int,
            previouslyFocusedRect: android.graphics.Rect?
        ) {
            // No focus-specific behaviour is required.
        }
    }

    private fun pinField(hintText: String) = EditText(this).apply {
        hint = hintText
        // Keep numeric input but never display the entered digits on screen.
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        transformationMethod = AsteriskPinTransformation()
        setTextColor(Color.WHITE)
        setHintTextColor(Color.LTGRAY)
        setSingleLine(true)
    }

    private fun setPinDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            setBackgroundColor(Color.BLACK)
        }
        val first = pinField("New PIN (4–8 digits)")
        val second = pinField("Confirm PIN")
        box.addView(first)
        box.addView(second)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Set app PIN")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = first.text.toString()
                val confirm = second.text.toString()
                when {
                    pin.length !in 4..8 || pin.any { !it.isDigit() } -> first.error = "Use 4–8 digits"
                    confirm.isEmpty() -> second.error = "Re-enter your PIN to confirm"
                    pin != confirm -> { second.text.clear(); second.error = "PINs do not match" }
                    else -> {
                        lockPrefs.edit().putString("pin", pin).apply()
                        lockPromptShown = false
                        dialog.dismiss()
                        Toast.makeText(this, "App PIN saved", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun requestUnlock() {
        val pin = lockPrefs.getString("pin", null) ?: return
        if (lockPromptShown) return
        lockPromptShown = true
        // Replace the dictionary with an opaque black screen before showing any lock UI.
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            addView(TextView(this@MainActivity).apply {
                text = "Briefcase"
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -1))
        })
        val biometricAvailable = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        if (lockPrefs.getBoolean("fingerprint", false) && biometricAvailable) {
            val executor = ContextCompat.getMainExecutor(this)
            val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    lockPromptShown = false
                    home()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    showPinUnlock(pin)
                }
                override fun onAuthenticationFailed() { }
            })
            prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Briefcase")
                .setSubtitle("Use fingerprint or enter your PIN")
                .setNegativeButtonText("Enter PIN")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build())
        } else showPinUnlock(pin)
    }

    private fun showPinUnlock(savedPin: String) {
        val field = pinField("PIN")
        val dialog = AlertDialog.Builder(this)
            .setTitle("Briefcase locked")
            .setMessage("Enter your PIN to continue")
            .setView(field)
            .setCancelable(false)
            .setPositiveButton("Unlock", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (field.text.toString() == savedPin) {
                    lockPromptShown = false
                    dialog.dismiss()
                    home()
                } else {
                    field.text.clear()
                    field.error = "Incorrect PIN"
                }
            }
        }
        dialog.show()
    }

    override fun onResume() { super.onResume(); requestUnlock() }

    private fun editor(old: Entry?) {
        currentPage = "editor"
        editorReturnEntry = old
        val page = column()
        page.addView(label(if (old == null) "Add word" else "Edit word", 14f))
        val word = inputField("Word", 13f).apply { setSingleLine(true); setText(old?.word ?: "") }
        val definition = inputField("Definition", 13f).apply { minLines = 3; gravity = Gravity.TOP; setText(old?.definition ?: "") }
        val example = inputField("Remarks (optional)", 13f).apply { minLines = 2; gravity = Gravity.TOP; setText(old?.example ?: "") }
        page.addView(word, LinearLayout.LayoutParams(-1, dp(40))); page.addView(definition, LinearLayout.LayoutParams(-1, dp(88))); page.addView(example, LinearLayout.LayoutParams(-1, dp(64)))
        page.addView(actionButton("Save").apply { setOnClickListener {
            val w = word.text.toString().trim(); val d = definition.text.toString().trim(); val x = example.text.toString().trim()
            if (w.isBlank() || d.isBlank()) { Toast.makeText(this@MainActivity, "Enter a word and definition", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (old != null) entries.removeAll { it.id == old.id }
            entries.add(Entry(old?.id ?: UUID.randomUUID().toString(), w, d, x)); entries.sortBy { it.word.lowercase() }; save()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(page.windowToken, 0)
            home()
        } })
        page.addView(actionButton("Cancel").apply { setOnClickListener { home() } })
        setContentView(page)
    }
}
