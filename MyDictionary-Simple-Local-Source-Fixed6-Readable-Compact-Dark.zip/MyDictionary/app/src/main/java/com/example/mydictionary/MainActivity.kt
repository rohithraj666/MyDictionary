package com.example.mydictionary

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(val id: String, val word: String, val definition: String, val example: String = "")

class MainActivity : AppCompatActivity() {
    private var entries = mutableListOf<Entry>()
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }
    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun actionButton(textValue: String, size: Float = 14f) = Button(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(Color.rgb(38, 38, 38))
        minHeight = dp(32)
    }

    private fun inputField(hintText: String, size: Float) = EditText(this).apply {
        hint = hintText
        textSize = size
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(165, 165, 165))
        backgroundTintList = ColorStateList.valueOf(Color.rgb(110, 110, 110))
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Use black system bars and keep content safely between them.
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        load(); home()
    }

    private fun load() {
        entries.clear()
        val raw = getSharedPreferences("my_dictionary", MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                entries.add(Entry(o.optString("id"), o.optString("word"), o.optString("definition"), o.optString("example")))
            }
        } catch (_: Exception) { }
        entries.sortBy { it.word.lowercase() }
    }

    private fun save() {
        val a = JSONArray()
        entries.forEach { a.put(JSONObject().put("id", it.id).put("word", it.word).put("definition", it.definition).put("example", it.example)) }
        getSharedPreferences("my_dictionary", MODE_PRIVATE).edit().putString("entries", a.toString()).apply()
    }

    private fun home() {
        root = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("My Dictionary", 17f), LinearLayout.LayoutParams(0, dp(30), 1f))
        top.addView(actionButton("+", 18f).apply { minWidth = dp(42); setOnClickListener { editor(null) } })
        root.addView(top)
        search = EditText(this).apply { hint = "Search words"; textSize = 13f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(165,165,165)); setSingleLine(true); setPadding(dp(5), 0, dp(5), 0); background = null }
        val searchBox = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), 0); setBackgroundColor(Color.rgb(24,24,24)) }
        searchBox.addView(label("⌕", 17f, Color.LTGRAY), LinearLayout.LayoutParams(dp(20), dp(28)))
        searchBox.addView(search, LinearLayout.LayoutParams(0, dp(28), 1f))
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(28)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root); render()
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        entries.filter { it.word.lowercase().contains(q) }.forEach { e ->
            list.addView(TextView(this).apply {
                text = e.word; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), 0, dp(6), 0); minHeight = dp(27); setBackgroundColor(Color.rgb(8,8,8)); setOnClickListener { details(e) }
            }, LinearLayout.LayoutParams(-1, dp(27)).apply { bottomMargin = 0 })
        }
    }

    private fun details(e: Entry) {
        val page = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(actionButton("‹").apply { setOnClickListener { home() } })
        top.addView(label(e.word, 17f), LinearLayout.LayoutParams(0, dp(46), 1f))
        top.addView(actionButton("Edit").apply { setOnClickListener { editor(e) } })
        page.addView(top)
        page.addView(label(e.definition, 13f).apply { setPadding(dp(2), dp(4), dp(2), dp(4)) })
        if (e.example.isNotBlank()) page.addView(label(e.example, 11f, Color.LTGRAY).apply { setPadding(dp(2), dp(2), dp(2), dp(4)) })
        page.addView(actionButton("Delete word").apply { setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setMessage("Delete ‘${e.word}’?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> entries.removeAll { it.id == e.id }; save(); home() }.show()
        } })
        setContentView(page)
    }

    private fun editor(old: Entry?) {
        val page = column()
        page.addView(label(if (old == null) "Add word" else "Edit word", 14f))
        val word = inputField("Word", 13f).apply { setSingleLine(true); setText(old?.word ?: "") }
        val definition = inputField("Definition", 13f).apply { minLines = 3; gravity = Gravity.TOP; setText(old?.definition ?: "") }
        val example = inputField("Example or note (optional)", 13f).apply { minLines = 2; gravity = Gravity.TOP; setText(old?.example ?: "") }
        page.addView(word, LinearLayout.LayoutParams(-1, dp(40))); page.addView(definition, LinearLayout.LayoutParams(-1, dp(88))); page.addView(example, LinearLayout.LayoutParams(-1, dp(64)))
        page.addView(actionButton("Save").apply { setOnClickListener {
            val w = word.text.toString().trim(); val d = definition.text.toString().trim(); val x = example.text.toString().trim()
            if (w.isBlank() || d.isBlank()) { Toast.makeText(this@MainActivity, "Enter a word and definition", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (old != null) entries.removeAll { it.id == old.id }
            entries.add(Entry(old?.id ?: UUID.randomUUID().toString(), w, d, x)); entries.sortBy { it.word.lowercase() }; save()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(page.windowToken, 0)
            home()
        } })
        page.addView(actionButton("Cancel").apply { setOnClickListener { home() } })
        setContentView(page)
    }
}
