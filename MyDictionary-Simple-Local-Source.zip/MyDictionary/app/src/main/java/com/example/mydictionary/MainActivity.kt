package com.example.mydictionary

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(val id: String, val word: String, val definition: String, val example: String = "")

class MainActivity : AppCompatActivity() {
    private var entries = mutableListOf<Entry>()
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float, color: Int = Color.rgb(55,55,55)) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }
    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load(); home()
    }

    private fun load() {
        entries.clear()
        val raw = getSharedPreferences("my_dictionary", MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                entries.add(Entry(o.optString("id"), o.optString("word"), o.optString("definition"), o.optString("example")))
            }
        } catch (_: Exception) { }
        entries.sortBy { it.word.lowercase() }
    }

    private fun save() {
        val a = JSONArray()
        entries.forEach { a.put(JSONObject().put("id", it.id).put("word", it.word).put("definition", it.definition).put("example", it.example)) }
        getSharedPreferences("my_dictionary", MODE_PRIVATE).edit().putString("entries", a.toString()).apply()
    }

    private fun home() {
        root = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("My Dictionary", 16f), LinearLayout.LayoutParams(0, dp(36), 1f))
        top.addView(Button(this).apply { text = "+"; textSize = 18f; minWidth = dp(42); setOnClickListener { editor(null) } })
        root.addView(top)
        search = EditText(this).apply { hint = "Search words"; textSize = 13f; singleLine = true; setPadding(dp(7), 0, dp(7), 0); background = null }
        val searchBox = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0); setBackgroundColor(Color.rgb(246,246,246)) }
        searchBox.addView(label("⌕", 17f, Color.GRAY), LinearLayout.LayoutParams(dp(24), dp(36)))
        searchBox.addView(search, LinearLayout.LayoutParams(0, dp(36), 1f))
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(36)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root); render()
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        entries.filter { it.word.lowercase().contains(q) }.forEach { e ->
            list.addView(TextView(this).apply {
                text = e.word; textSize = 12f; setTextColor(Color.rgb(65,65,65)); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), 0, dp(2), 0); minHeight = dp(23); setOnClickListener { details(e) }
            }, LinearLayout.LayoutParams(-1, dp(23)))
        }
    }

    private fun details(e: Entry) {
        val page = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Button(this).apply { text = "‹"; setOnClickListener { home() } })
        top.addView(label(e.word, 17f), LinearLayout.LayoutParams(0, dp(46), 1f))
        top.addView(Button(this).apply { text = "Edit"; setOnClickListener { editor(e) } })
        page.addView(top)
        page.addView(label(e.definition, 14f).apply { setPadding(dp(2), dp(14), dp(2), dp(10)) })
        if (e.example.isNotBlank()) page.addView(label(e.example, 12f, Color.DKGRAY).apply { setPadding(dp(2), dp(4), dp(2), dp(8)) })
        page.addView(Button(this).apply { text = "Delete word"; setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setMessage("Delete ‘${e.word}’?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> entries.removeAll { it.id == e.id }; save(); home() }.show()
        } })
        setContentView(page)
    }

    private fun editor(old: Entry?) {
        val page = column()
        page.addView(label(if (old == null) "Add word" else "Edit word", 16f))
        val word = EditText(this).apply { hint = "Word"; textSize = 14f; setSingleLine(true); setText(old?.word ?: "") }
        val definition = EditText(this).apply { hint = "Definition"; textSize = 14f; minLines = 3; gravity = Gravity.TOP; setText(old?.definition ?: "") }
        val example = EditText(this).apply { hint = "Example or note (optional)"; textSize = 13f; minLines = 2; gravity = Gravity.TOP; setText(old?.example ?: "") }
        page.addView(word, LinearLayout.LayoutParams(-1, dp(48))); page.addView(definition, LinearLayout.LayoutParams(-1, dp(108))); page.addView(example, LinearLayout.LayoutParams(-1, dp(78)))
        page.addView(Button(this).apply { text = "Save"; setOnClickListener {
            val w = word.text.toString().trim(); val d = definition.text.toString().trim(); val x = example.text.toString().trim()
            if (w.isBlank() || d.isBlank()) { Toast.makeText(this@MainActivity, "Enter a word and definition", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (old != null) entries.removeAll { it.id == old.id }
            entries.add(Entry(old?.id ?: UUID.randomUUID().toString(), w, d, x)); entries.sortBy { it.word.lowercase() }; save()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(page.windowToken, 0)
            home()
        } })
        page.addView(Button(this).apply { text = "Cancel"; setOnClickListener { home() } })
        setContentView(page)
    }
}
