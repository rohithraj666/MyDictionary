# My Dictionary — simple Android app

- No Google sign-in, Firebase, ads, analytics, or internet permission.
- Words are saved only on this phone.
- Search bar at the top; compact 12sp word list with approximately 23dp rows.
- Tap a word to see its definition and optional example/note.
- Add, edit, and delete entries.

## Build an APK

Open this folder in Android Studio, let Gradle sync, then select **Build > Build APK(s)**. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow in `.github/workflows/build-apk.yml` can also build the APK remotely after this project is uploaded to a GitHub repository. The generated APK is downloadable from the workflow run's **Artifacts** section.
