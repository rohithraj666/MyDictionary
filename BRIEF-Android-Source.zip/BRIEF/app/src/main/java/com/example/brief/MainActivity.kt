package com.example.brief

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(val id: String, val title: String, val description: String)

class MainActivity : AppCompatActivity() {
    private var entries = mutableListOf<Entry>()
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private var currentPage = "home"
    private var editorReturnEntry: Entry? = null

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) exportEntries(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importEntries(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(textValue: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.BLACK)
        setPadding(dp(10), dp(6), dp(10), dp(8))
    }

    private fun actionButton(textValue: String, size: Float = 15f) = Button(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(Color.rgb(38, 38, 38))
        minHeight = dp(38)
    }

    private fun inputField(hintText: String, size: Float) = EditText(this).apply {
        hint = hintText
        textSize = size
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(165, 165, 165))
        backgroundTintList = ColorStateList.valueOf(Color.rgb(110, 110, 110))
        setPadding(dp(9), dp(8), dp(9), dp(8))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        load()
        home()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (currentPage) {
            "details" -> home()
            "editor" -> {
                val previous = editorReturnEntry
                if (previous != null) {
                    val updated = entries.firstOrNull { it.id == previous.id } ?: previous
                    details(updated)
                } else home()
            }
            else -> super.onBackPressed()
        }
    }

    private fun load() {
        entries.clear()
        val raw = getSharedPreferences("brief_data", MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val title = o.optString("title").ifBlank { o.optString("word") }
                val description = o.optString("description").ifBlank { o.optString("definition") }
                if (title.isNotBlank()) entries.add(Entry(o.optString("id").ifBlank { UUID.randomUUID().toString() }, title, description))
            }
        } catch (_: Exception) { }
        entries.sortBy { it.title.lowercase() }
    }

    private fun save() {
        val array = JSONArray()
        entries.forEach { e ->
            // Keep the original dictionary keys so old JSON backups remain compatible.
            array.put(JSONObject()
                .put("id", e.id)
                .put("word", e.title)
                .put("definition", e.description)
                .put("example", ""))
        }
        getSharedPreferences("brief_data", MODE_PRIVATE).edit().putString("entries", array.toString()).apply()
    }

    private fun home() {
        currentPage = "home"
        editorReturnEntry = null
        val root = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("BRIEF", 21f), LinearLayout.LayoutParams(0, dp(42), 1f))
        top.addView(actionButton("+", 21f).apply { minWidth = dp(48); setOnClickListener { editor(null) } })
        top.addView(actionButton("⋮", 21f).apply {
            minWidth = dp(42)
            setOnClickListener { showDataMenu(this) }
        })
        root.addView(top)

        search = EditText(this).apply {
            hint = "Search titles"
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(165, 165, 165))
            setSingleLine(true)
            setPadding(dp(7), dp(2), dp(7), dp(2))
            background = null
        }
        val searchBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(2), dp(5), dp(2))
            setBackgroundColor(Color.rgb(24, 24, 24))
        }
        searchBox.addView(label("⌕", 20f, Color.LTGRAY), LinearLayout.LayoutParams(dp(26), dp(38)))
        searchBox.addView(search, LinearLayout.LayoutParams(0, dp(38), 1f))
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(42)))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root)
        render()
    }

    private fun showDataMenu(anchor: View) {
        val popup = android.widget.PopupMenu(this, anchor)
        popup.menu.add("Export data to file")
        popup.menu.add("Import data from file")
        popup.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Export data to file" -> exportLauncher.launch("brief_backup.json")
                "Import data from file" -> importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream"))
            }
            true
        }
        popup.show()
    }

    private fun exportEntries(uri: Uri) {
        try {
            val array = JSONArray()
            entries.forEach { e ->
                array.put(JSONObject().put("id", e.id).put("word", e.title).put("definition", e.description).put("example", ""))
            }
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(array.toString(2)) }
                ?: throw IllegalStateException("Could not open the selected file")
            Toast.makeText(this, "Exported ${entries.size} entries", Toast.LENGTH_LONG).show()
        } catch (ex: Exception) {
            Toast.makeText(this, "Export failed: ${ex.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importEntries(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Could not read the selected file")
            val array = JSONArray(raw)
            val imported = mutableListOf<Entry>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val title = o.optString("title").ifBlank { o.optString("word") }.trim()
                val description = o.optString("description").ifBlank { o.optString("definition") }
                if (title.isNotBlank()) {
                    imported.add(Entry(o.optString("id").ifBlank { UUID.randomUUID().toString() }, title, description))
                }
            }
            if (imported.isEmpty() && array.length() > 0) throw IllegalArgumentException("No valid entries found")
            AlertDialog.Builder(this)
                .setTitle("Import data")
                .setMessage("Found ${imported.size} entries. Replace your current list, or merge with existing entries? Matching titles are identified by title.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Replace") { _, _ ->
                    entries = imported.distinctBy { it.title.lowercase() }.toMutableList()
                    entries.sortBy { it.title.lowercase() }
                    save(); home()
                    Toast.makeText(this, "Imported ${entries.size} entries", Toast.LENGTH_LONG).show()
                }
                .setPositiveButton("Merge") { _, _ ->
                    val combined = entries.toMutableList()
                    imported.forEach { incoming ->
                        val index = combined.indexOfFirst { it.title.equals(incoming.title, ignoreCase = true) }
                        if (index >= 0) combined[index] = incoming else combined.add(incoming)
                    }
                    entries = combined.distinctBy { it.title.lowercase() }.toMutableList()
                    entries.sortBy { it.title.lowercase() }
                    save(); home()
                    Toast.makeText(this, "Imported entries; total ${entries.size}", Toast.LENGTH_LONG).show()
                }
                .show()
        } catch (_: Exception) {
            Toast.makeText(this, "Import failed. Choose a valid JSON backup file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val query = search.text.toString().trim().lowercase()
        val filtered = entries.filter { it.title.lowercase().contains(query) }
        if (filtered.isEmpty()) {
            list.addView(label(if (query.isEmpty()) "No entries yet. Tap + to add one." else "No matching titles", 16f, Color.LTGRAY).apply {
                setPadding(dp(8), dp(18), dp(8), dp(18))
            })
        }
        filtered.forEach { entry ->
            list.addView(TextView(this).apply {
                text = entry.title
                textSize = 17f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(2), dp(8), dp(2))
                minHeight = dp(42)
                setBackgroundColor(Color.rgb(8, 8, 8))
                setOnClickListener { details(entry) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) })
        }
    }

    private fun details(entry: Entry) {
        currentPage = "details"
        editorReturnEntry = null
        val page = column()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(actionButton("‹").apply { setOnClickListener { home() } })
        top.addView(label("Details", 15f, Color.LTGRAY), LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(actionButton("Edit").apply {
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(40))
            setOnClickListener { editor(entry) }
        })
        page.addView(top)

        page.addView(label("Title", 14f, Color.LTGRAY).apply { setPadding(dp(3), dp(8), 0, dp(2)) })
        page.addView(TextView(this).apply {
            text = entry.title
            textSize = 22f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(dp(4), dp(5), dp(4), dp(12))
        }, LinearLayout.LayoutParams(-1, -2))

        page.addView(label("Description", 14f, Color.LTGRAY).apply { setPadding(dp(3), dp(6), 0, dp(2)) })
        val description = TextView(this).apply {
            text = entry.description
            textSize = 18f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(dp(4), dp(5), dp(4), dp(14))
            gravity = Gravity.TOP or Gravity.START
        }
        page.addView(ScrollView(this).apply { addView(description) }, LinearLayout.LayoutParams(-1, 0, 1f))

        page.addView(actionButton("Delete").apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("Delete ‘${entry.title}’?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ -> entries.removeAll { it.id == entry.id }; save(); home() }
                    .show()
            }
        })
        setContentView(page)
    }

    private fun editor(old: Entry?) {
        currentPage = "editor"
        editorReturnEntry = old
        val page = column()
        page.addView(label(if (old == null) "Add entry" else "Edit entry", 19f))

        val titleInput = inputField("Title", 17f).apply {
            setSingleLine(true)
            setText(old?.title ?: "")
        }
        page.addView(titleInput, LinearLayout.LayoutParams(-1, dp(54)))

        page.addView(label("Description", 15f, Color.LTGRAY).apply { setPadding(dp(2), dp(7), 0, dp(3)) })
        val descriptionInput = inputField("Enter description (no length limit)", 17f).apply {
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            setSingleLine(false)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(old?.description ?: "")
        }
        val editorScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(descriptionInput, ScrollView.LayoutParams(-1, -2))
        }
        page.addView(editorScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        page.addView(actionButton("Save").apply {
            setOnClickListener {
                val title = titleInput.text.toString().trim()
                val description = descriptionInput.text.toString().trim()
                if (title.isBlank()) {
                    titleInput.error = "Enter a title"
                    return@setOnClickListener
                }
                if (old != null) entries.removeAll { it.id == old.id }
                entries.add(Entry(old?.id ?: UUID.randomUUID().toString(), title, description))
                entries.sortBy { it.title.lowercase() }
                save()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(page.windowToken, 0)
                home()
            }
        })
        page.addView(actionButton("Cancel").apply { setOnClickListener { if (old != null) details(entries.firstOrNull { it.id == old.id } ?: old) else home() } })
        setContentView(page)
    }
}
