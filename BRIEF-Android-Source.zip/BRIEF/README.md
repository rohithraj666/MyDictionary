# BRIEF Android app source

A compact, offline title-and-description app with a black theme.

Features:
- App name: BRIEF
- Add, edit, search, view, and delete entries
- Title and multiline description, with no application-imposed description length limit
- Selectable title and description text in details for Android text-selection/copy actions
- JSON import/export compatible with prior dictionary backups (`word`, `definition`, and optional `example` fields); exported `example` is empty because remarks were removed
- No PIN or biometric lock
- Larger text than the previous Briefcase app

Build locally from this directory with Gradle, or use GitHub Actions after uploading the project files into a repository root.
